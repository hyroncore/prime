using Microsoft.EntityFrameworkCore;

namespace Prime.Api.Data;

public static class DbSeeder
{
    public static void Seed(PrimeDbContext db)
    {
        db.Database.Migrate();
    }
}