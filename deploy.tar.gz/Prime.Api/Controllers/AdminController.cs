using Microsoft.AspNetCore.Mvc;
using Prime.Api.Data;

namespace Prime.Api.Controllers;

[ApiController]
[Route("api/admin")]
public class AdminController : ControllerBase
{
    private readonly PrimeDbContext _db;
    private readonly IWebHostEnvironment _env;

    public AdminController(PrimeDbContext db, IWebHostEnvironment env)
    {
        _db = db;
        _env = env;
    }

    [HttpPost("reset")]
    public async Task<IActionResult> Reset()
    {
        _db.RequisitionAuditLogs.RemoveRange(_db.RequisitionAuditLogs);
        _db.RequisitionSequences.RemoveRange(_db.RequisitionSequences);
        _db.RequisitionAttachments.RemoveRange(_db.RequisitionAttachments);
        _db.PurchaseRequisitions.RemoveRange(_db.PurchaseRequisitions);
        _db.Plants.RemoveRange(_db.Plants);
        _db.Clients.RemoveRange(_db.Clients);

        await _db.SaveChangesAsync();

        var uploadsRoot = Path.Combine(_env.ContentRootPath, "uploads");
        if (Directory.Exists(uploadsRoot))
        {
            Directory.Delete(uploadsRoot, recursive: true);
        }

        return Ok(new { message = "تم مسح جميع البيانات بنجاح" });
    }
}